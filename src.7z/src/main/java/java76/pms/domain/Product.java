package java76.pms.domain;

import java.sql.Date;

public class Product {
  protected String name;
  protected Date date;
  protected String story;
  protected String photo;
  protected int grade;
  protected String kind;
  protected int amount;
  protected int rentcount;
  protected String genre;
  protected String rentmember;
  protected String reply;
  
  
  
  public String getReply() {
    return reply;
  }

  public void setReply(String reply) {
    this.reply = reply;
  }

  public String getRentmember() {
    return rentmember;
  }

  public void setRentmember(String rentmember) {
    this.rentmember = rentmember;
  }
  



  public String getGenre() {
    return genre;
  }
  


  public void setGenre(String genre) {
    this.genre = genre;
  }
  



  public int getRentcount() {
    return rentcount;
  }
  



  public void setRentcount(int rentcount) {
    this.rentcount = rentcount;
  }
  



  public String getName() {
    return name;
  }
  
  public void setName(String name) {
    this.name = name;
  }
  
  public Date getDate() {
    return date;
  }
  
  public void setDate(Date date) {
    this.date = date;
  }
  
  
  public int getAmount() {
    return amount;
  }
  

  public void setAmount(int amount) {
    this.amount = amount;
  }
  
  public String getPhoto() {
    return photo;
  }
  
  public void setPhoto(String photo) {
    this.photo = photo;
  }
  
   
  
  public String getKind() {
    return kind;
  }
  

  public String getStory() {
    return story;
  }

  public void setStory(String story) {
    this.story = story;
  }
  
  
  public void setKind(String kind) {
    this.kind = kind;
  }

  public int getGrade() {
    return grade;
  }


  public void setGrade(int grade) {
    this.grade = grade;
  }
  
  
  
  
  
}
